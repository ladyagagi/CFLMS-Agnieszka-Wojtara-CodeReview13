<?php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response ;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use App\Entity\Event;
use Symfony\Component\Form\Extension\Core\Type\NumberType;

class EventController extends AbstractController
{
    // /**
    //  * @Route("/event", name="event")
    //  */
    // public function index()
    // {
    //     return $this->render('event/event.html.twig', [
    //         'controller_name' => 'EventController',
    //     ]);
    // }

    /**
    * @Route("/event", name="event")
    */ 
    public function events()
    {
        $events = $this->getDoctrine()
            ->getRepository(Event::class)
            ->findAll();
        
                    return $this->render("event/event.html.twig", array("events"=>$events));
                }

    /**
    * @Route("/create", name="createAction")
    */
   public function createAction(Request $request)
   {  
       $event = new Event;
       $form = $this->createFormBuilder($event)
       ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('date', DateTimeType::class, array('attr' => array('class'=> 'input-append date form_datetime', 'type' =>'datetime', 'style'=>'margin-bottom:15px')))
       ->add('description', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('img', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('pax', IntegerType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'type' =>'email', 'style'=>'margin-bottom:15px')))
       ->add('mobile', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('type', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

       ->add('save', SubmitType::class, array('label'=> 'Create a new event', 'attr' => array('class'=> 'btn btn-primary', 'style'=>'margin-bottom:15px')))
       ->add('back', SubmitType::class, array('label'=> 'back to the list', 'attr' => array('class'=> 'btn btn-outline-primary mb-4 btn-sm', 'style'=>'margin-botton:15px')))

       ->getForm();
       $form->handleRequest($request);

       if($form->isSubmitted() && $form->isValid()){
        //fetching data

        // taking the data from the inputs by the name of the inputs then getData() function
        $name = $form['name']->getData();
        $date = $form['date']->getData();
        $description = $form['description']->getData();
        $img = $form['img']->getData();
        $pax = $form['pax']->getData();
        $email = $form['email']->getData();
        $mobile = $form['mobile']->getData();
        $address = $form['address']->getData();
        $url = $form['url']->getData();
        $type = $form['type']->getData();

        $event->setName($name);
        $event->setDate($date);
        $event->setDescription($description);
        $event->setImg($img);
        $event->setPax($pax);
        $event->setEmail($email);
        $event->setMobile($mobile);
        $event->setAddress($address);
        $event->setUrl($url);
        $event->setType($type);
        $em = $this->getDoctrine()->getManager();
        $em->persist($event);
        $em->flush();
        $this->addFlash(
                'notice',
                'Event Added'
                );
        return $this->redirectToRoute('event');
    }

    return $this->render('event/create.html.twig', array('form' => $form->createView()));
}        
       /**
        * @Route("/details/{id}", name="detailsAction")
        */ 
        public function detailsAction($id)
        {
            $event = $this->getDoctrine()
                ->getRepository(Event::class)
                ->find($id); //build-in function ** find()
             if (!$event) {
                throw  $this->createNotFoundException(
                     'No event found for id '.$id
                );
            } else {
                    //  return new Response('Details from the product with id ' .$productId.", Product name is ".$product->getName()." and it costs " .$product->getPrice()."€");
                     return $this->render("event/details.html.twig", array("event"=>$event));
                    }
         }

          /**
    * @Route("/edit/{id}", name="edit_event")
    */
    public function editAction($id, Request $request)
    {
        $event = $this-> getDoctrine()->getRepository('App:Event')->find($id);
       

        $event->setName($event->getName());
        $event->setDate($event->getDate());
        $event->setDescription($event->getDescription());
        $event->setImg($event->getImg());
        $event->setPax($event->getPax());
        $event->setEmail($event->getEmail());
        $event->setMobile($event->getMobile());
        $event->setAddress($event->getAddress());
        $event->setUrl($event->getUrl());
        $event->setType($event->getType());

        $form = $this->createFormBuilder($event)
        ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('date', DateTimeType::class, array('attr' => array('class'=> 'form-control', 'type' =>'date', 'style'=>'margin-bottom:15px')))
        ->add('description', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('img', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('pax', IntegerType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'type' =>'email', 'style'=>'margin-bottom:15px')))
        ->add('mobile', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('type', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('save', SubmitType::class, array('label'=> 'Update Event', 'attr' => array('class'=> 'btn btn-primary mb-4 btn-sm', 'style'=>'margin-botton:15px')))
        ->add('back', SubmitType::class, array('label'=> 'back to the list', 'attr' => array('class'=> 'btn btn-outline-primary mb-4 btn-sm', 'style'=>'margin-botton:15px')))

        ->getForm();
        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){
            //fetching data

            $name = $form['name']->getData();
            $date = $form['date']->getData();
            $description = $form['description']->getData();
            $img = $form['img']->getData();
            $pax = $form['pax']->getData();
            $email = $form['email']->getData();
            $mobile = $form['mobile']->getData();
            $address = $form['address']->getData();
            $url = $form['url']->getData();
            $type = $form['type']->getData();

            $em = $this->getDoctrine()->getManager();
            $event = $em->getRepository('App:Event')->find($id);

            $event->setName($name);
            $event->setDate($date);
            $event->setDescription($description);
            $event->setImg($img);
            $event->setPax($pax);
            $event->setEmail($email);
            $event->setMobile($mobile);
            $event->setAddress($address);
            $event->setUrl($url);
            $event->setType($type);
            $em->flush();
            $this->addFlash(
                    'notice',
                    'Event Updated'
                    );
            return $this->redirectToRoute('event');
        }

    return $this->render('event/edit.html.twig', array('event' => $event, 'form' => $form->createView()));
    }

       /**
        * @Route("/delete/{id}", name="event_delete")
        */
        public function deleteAction($id){
            $em = $this->getDoctrine()->getManager();
            $event = $em->getRepository('App:Event')->find($id);
            $em->remove($event);
            $em->flush();
            $this->addFlash(
                'notice',
                'Event Removed'
                );
            return $this->redirectToRoute('event');
    }

}